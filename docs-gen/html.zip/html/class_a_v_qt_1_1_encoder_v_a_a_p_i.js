var class_a_v_qt_1_1_encoder_v_a_a_p_i =
[
    [ "AUDIO_CODEC", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#ac5e1b8a75fde7cd737032bea08684b7c", [
      [ "AAC", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#ac5e1b8a75fde7cd737032bea08684b7ca6409dac0c80c79ddf61858be7f2c699b", null ],
      [ "OGG", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#ac5e1b8a75fde7cd737032bea08684b7cae94afc367f47e1aaf16533e4ecbc8716", null ],
      [ "OPUS", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#ac5e1b8a75fde7cd737032bea08684b7ca4c2223596711a6a941bc19e8067ceef9", null ]
    ] ],
    [ "VIDEO_CODEC", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a5a1cbe7bfbaeeda438c21c39901e88dc", [
      [ "H264", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a5a1cbe7bfbaeeda438c21c39901e88dca8ba63b54352f7053b055235a9ec7ac09", null ],
      [ "HEVC", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a5a1cbe7bfbaeeda438c21c39901e88dcaedc93b70a6a3d160422ba8e728919af1", null ],
      [ "VP9", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a5a1cbe7bfbaeeda438c21c39901e88dcaae4cfaa9283a4f2150ac3da08e388723", null ]
    ] ],
    [ "EncoderVAAPI", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a18ecc094514d5f673a3436c12070a871", null ],
    [ "~EncoderVAAPI", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a62f2d04a74ce58981fbd636d496fad4c", null ],
    [ "EncoderVAAPI", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a8da85138668cfcdd68d3870c32f69dbe", null ],
    [ "deinit", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a4889e6dd02a5625f6a577a5be85cd990", null ],
    [ "init", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a94e5feee994a6aeb0fcca935b87e1b04", null ],
    [ "isPaused", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#aa0d67236ce5821c60c01f0236f734624", null ],
    [ "onFrame", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a09ec36fde99f78820afd04db85abed72", null ],
    [ "onFrame", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#aedd1475224c1fbe7f5cd486335561ad5", null ],
    [ "pause", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#ae1494a35d0c991176b117c25b801f23d", null ],
    [ "run", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a72055f7611a20d68e9f3df424158ca24", null ],
    [ "start", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#ac6eb460015f1ca131325ff15d92855ff", null ],
    [ "started", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a50ce856ea4f3393069cf1917842e322b", null ],
    [ "stop", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#acf8e2bc869ddd725d3762e794f58409e", null ],
    [ "stopped", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a8889e577f5f9c9d0895dc75a2061fd6c", null ]
];