var struct_a_v_qt_1_1_open_g_l_widget_renderer_private =
[
    [ "OpenGLWidgetRendererPrivate", "struct_a_v_qt_1_1_open_g_l_widget_renderer_private.html#ad0e21c0e8b87181bcf53ed2a870eff5c", null ],
    [ "q_ptr", "struct_a_v_qt_1_1_open_g_l_widget_renderer_private.html#a17805998b2f9d71d064684b6de0b592f", null ]
];