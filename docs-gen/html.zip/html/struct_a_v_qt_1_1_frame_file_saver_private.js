var struct_a_v_qt_1_1_frame_file_saver_private =
[
    [ "FrameFileSaverPrivate", "struct_a_v_qt_1_1_frame_file_saver_private.html#a7df5f391d825052c0266c3d3e6533769", null ],
    [ "m_filePrefix", "struct_a_v_qt_1_1_frame_file_saver_private.html#a43c56068bdeeb6d1550b427efcde2c0b", null ],
    [ "m_frameInterval", "struct_a_v_qt_1_1_frame_file_saver_private.html#a208fad5eb241809bdf336bd1fb412e13", null ],
    [ "m_frameNumber", "struct_a_v_qt_1_1_frame_file_saver_private.html#a3b350cbc9b0e2ba70986d86652030f28", null ],
    [ "m_isPaused", "struct_a_v_qt_1_1_frame_file_saver_private.html#ae99dc7c8da1ce47c9cf3e49919d32d9c", null ],
    [ "q_ptr", "struct_a_v_qt_1_1_frame_file_saver_private.html#aba9b1ffe10a6463398a45a1d1412cbaa", null ]
];