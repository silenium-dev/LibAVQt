var dir_59ca59df20242c4b3a7e1795593e9617 =
[
    [ "private", "dir_6aa36777f48736a4cef766f670448573.html", "dir_6aa36777f48736a4cef766f670448573" ],
    [ "EncoderVAAPI.cpp", "_encoder_v_a_a_p_i_8cpp.html", "_encoder_v_a_a_p_i_8cpp" ],
    [ "EncoderVAAPI.h", "_encoder_v_a_a_p_i_8h.html", [
      [ "EncoderVAAPI", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html", "class_a_v_qt_1_1_encoder_v_a_a_p_i" ]
    ] ],
    [ "FrameFileSaver.cpp", "_frame_file_saver_8cpp.html", null ],
    [ "FrameFileSaver.h", "_frame_file_saver_8h.html", [
      [ "FrameFileSaver", "class_a_v_qt_1_1_frame_file_saver.html", "class_a_v_qt_1_1_frame_file_saver" ]
    ] ],
    [ "IFrameSink.h", "_i_frame_sink_8h.html", [
      [ "IFrameSink", "class_a_v_qt_1_1_i_frame_sink.html", "class_a_v_qt_1_1_i_frame_sink" ]
    ] ],
    [ "OpenGLWidgetRenderer.cpp", "_open_g_l_widget_renderer_8cpp.html", null ],
    [ "OpenGLWidgetRenderer.h", "_open_g_l_widget_renderer_8h.html", [
      [ "OpenGLWidgetRenderer", "class_a_v_qt_1_1_open_g_l_widget_renderer.html", "class_a_v_qt_1_1_open_g_l_widget_renderer" ]
    ] ]
];