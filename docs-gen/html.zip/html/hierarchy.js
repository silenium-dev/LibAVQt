var hierarchy =
[
    [ "AVQt::DecoderVAAPIPrivate", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html", null ],
    [ "AVQt::EncoderVAAPIPrivate", "struct_a_v_qt_1_1_encoder_v_a_a_p_i_private.html", null ],
    [ "AVQt::EncoderVAAPIPrivate::Frame", "struct_a_v_qt_1_1_encoder_v_a_a_p_i_private_1_1_frame.html", null ],
    [ "AVQt::IFrameSink", "class_a_v_qt_1_1_i_frame_sink.html", [
      [ "AVQt::EncoderVAAPI", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html", null ],
      [ "AVQt::FrameFileSaver", "class_a_v_qt_1_1_frame_file_saver.html", null ],
      [ "AVQt::OpenGLWidgetRenderer", "class_a_v_qt_1_1_open_g_l_widget_renderer.html", null ]
    ] ],
    [ "AVQt::IFrameSource", "class_a_v_qt_1_1_i_frame_source.html", [
      [ "AVQt::DecoderVAAPI", "class_a_v_qt_1_1_decoder_v_a_a_p_i.html", null ]
    ] ],
    [ "QObject", null, [
      [ "AVQt::FrameFileSaver", "class_a_v_qt_1_1_frame_file_saver.html", null ]
    ] ],
    [ "QOpenGLWidget", null, [
      [ "AVQt::OpenGLWidgetRenderer", "class_a_v_qt_1_1_open_g_l_widget_renderer.html", null ]
    ] ],
    [ "QThread", null, [
      [ "AVQt::DecoderVAAPI", "class_a_v_qt_1_1_decoder_v_a_a_p_i.html", null ],
      [ "AVQt::EncoderVAAPI", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html", null ]
    ] ]
];