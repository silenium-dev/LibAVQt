var annotated_dup =
[
    [ "AVQt", "namespace_a_v_qt.html", [
      [ "DecoderVAAPI", "class_a_v_qt_1_1_decoder_v_a_a_p_i.html", "class_a_v_qt_1_1_decoder_v_a_a_p_i" ],
      [ "IFrameSource", "class_a_v_qt_1_1_i_frame_source.html", "class_a_v_qt_1_1_i_frame_source" ],
      [ "DecoderVAAPIPrivate", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private" ],
      [ "EncoderVAAPI", "class_a_v_qt_1_1_encoder_v_a_a_p_i.html", "class_a_v_qt_1_1_encoder_v_a_a_p_i" ],
      [ "FrameFileSaver", "class_a_v_qt_1_1_frame_file_saver.html", "class_a_v_qt_1_1_frame_file_saver" ],
      [ "IFrameSink", "class_a_v_qt_1_1_i_frame_sink.html", "class_a_v_qt_1_1_i_frame_sink" ],
      [ "OpenGLWidgetRenderer", "class_a_v_qt_1_1_open_g_l_widget_renderer.html", "class_a_v_qt_1_1_open_g_l_widget_renderer" ],
      [ "EncoderVAAPIPrivate", "struct_a_v_qt_1_1_encoder_v_a_a_p_i_private.html", "struct_a_v_qt_1_1_encoder_v_a_a_p_i_private" ]
    ] ]
];