var struct_a_v_qt_1_1_decoder_v_a_a_p_i_private =
[
    [ "DecoderVAAPIPrivate", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#a4bb258fbfc39df6061bce7af54e4db02", null ],
    [ "m_audioIndex", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#a46982455f244b34d77ec56ded51e8389", null ],
    [ "m_avfCallbacks", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#ae5998bf429ea2e8686c0972541321d64", null ],
    [ "m_inputDevice", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#a7d0afba0685021865fee9cf1c447b328", null ],
    [ "m_isPaused", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#a3eb2960ca00494d4fc44baf9bd6d48a1", null ],
    [ "m_isRunning", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#a9dd0df1ada97709fa3a6764d5b24cec4", null ],
    [ "m_pAudioCodec", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#a93a5d95b88ca570df5e1f32463745f60", null ],
    [ "m_pAudioCodecCtx", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#a47b2e50f2063b9e14965c0317dfb7647", null ],
    [ "m_pCurrentBGRAFrame", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#abff8d3ae9bf74fa7879d7c7013a70286", null ],
    [ "m_pCurrentFrame", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#a8b5e0a065ab43853e279305f39c76765", null ],
    [ "m_pDeviceCtx", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#ac21f3f0fef7e2ff1b034c3a2db92aa15", null ],
    [ "m_pFormatCtx", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#a1d92034d588ba1b18ae9b3be593b5a1a", null ],
    [ "m_pInputCtx", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#ac581d29e353cd0ec57d3ceb5e4978c80", null ],
    [ "m_pIOBuffer", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#ae53fa750e9187d1926587928c48042a3", null ],
    [ "m_pSwsContext", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#a466fc0394a9209a99c514702b0c03c5e", null ],
    [ "m_pVideoCodec", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#a36e494e292d58ee69cc7d460788d97ba", null ],
    [ "m_pVideoCodecCtx", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#a26575058277b28968ae4da60fce8b988", null ],
    [ "m_qiCallbacks", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#adc436f170972e7cc4936d99a016253e8", null ],
    [ "m_videoIndex", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#a40bbe0702045443ddb50d7a4a9ee5da0", null ],
    [ "q_ptr", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#ad5b8d6a13839b5a44870ab87d4506885", null ]
];