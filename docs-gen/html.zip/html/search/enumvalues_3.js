var searchData=
[
  ['ogg_215',['OGG',['../class_a_v_qt_1_1_encoder_v_a_a_p_i.html#ac5e1b8a75fde7cd737032bea08684b7cae94afc367f47e1aaf16533e4ecbc8716',1,'AVQt::EncoderVAAPI']]],
  ['opus_216',['OPUS',['../class_a_v_qt_1_1_encoder_v_a_a_p_i.html#ac5e1b8a75fde7cd737032bea08684b7ca4c2223596711a6a941bc19e8067ceef9',1,'AVQt::EncoderVAAPI']]]
];
