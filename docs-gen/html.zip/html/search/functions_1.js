var searchData=
[
  ['encodervaapi_135',['EncoderVAAPI',['../class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a18ecc094514d5f673a3436c12070a871',1,'AVQt::EncoderVAAPI::EncoderVAAPI(QIODevice *outputDevice, VIDEO_CODEC videoCodec, AUDIO_CODEC audioCodec, int width, int height, AVRational framerate, int bitrate, QObject *parent=nullptr)'],['../class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a8da85138668cfcdd68d3870c32f69dbe',1,'AVQt::EncoderVAAPI::EncoderVAAPI(EncoderVAAPIPrivate &amp;p)']]],
  ['encodervaapiprivate_136',['EncoderVAAPIPrivate',['../struct_a_v_qt_1_1_encoder_v_a_a_p_i_private.html#acede0078779ce897ba7c145737568040',1,'AVQt::EncoderVAAPIPrivate']]]
];
