var searchData=
[
  ['now_218',['NOW',['../_encoder_v_a_a_p_i_8cpp.html#a9e1f10144cee8f7e6efb6408fb0f8f34',1,'EncoderVAAPI.cpp']]]
];
