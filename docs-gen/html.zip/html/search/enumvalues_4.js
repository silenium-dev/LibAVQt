var searchData=
[
  ['vp9_217',['VP9',['../class_a_v_qt_1_1_encoder_v_a_a_p_i.html#a5a1cbe7bfbaeeda438c21c39901e88dcaae4cfaa9283a4f2150ac3da08e388723',1,'AVQt::EncoderVAAPI']]]
];
