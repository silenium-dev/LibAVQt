var searchData=
[
  ['unregistercallback_101',['unregisterCallback',['../class_a_v_qt_1_1_decoder_v_a_a_p_i.html#aca4a28db4a154a2939d96e7f085fd4a3',1,'AVQt::DecoderVAAPI::unregisterCallback()'],['../class_a_v_qt_1_1_i_frame_source.html#a7a31d67d2120a810e7fd1a3fc381eeeb',1,'AVQt::IFrameSource::unregisterCallback()']]]
];
