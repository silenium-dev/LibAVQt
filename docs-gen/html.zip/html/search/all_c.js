var searchData=
[
  ['q_5fptr_88',['q_ptr',['../struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html#ad5b8d6a13839b5a44870ab87d4506885',1,'AVQt::DecoderVAAPIPrivate::q_ptr()'],['../struct_a_v_qt_1_1_encoder_v_a_a_p_i_private.html#a41446021416018f9171c165cb251ddb7',1,'AVQt::EncoderVAAPIPrivate::q_ptr()']]]
];
