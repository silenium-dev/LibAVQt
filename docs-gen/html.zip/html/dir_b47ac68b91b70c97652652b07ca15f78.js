var dir_b47ac68b91b70c97652652b07ca15f78 =
[
    [ "DecoderVAAPI_p.h", "_decoder_v_a_a_p_i__p_8h.html", [
      [ "DecoderVAAPIPrivate", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private.html", "struct_a_v_qt_1_1_decoder_v_a_a_p_i_private" ]
    ] ]
];