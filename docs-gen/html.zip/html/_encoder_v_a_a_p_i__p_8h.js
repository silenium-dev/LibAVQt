var _encoder_v_a_a_p_i__p_8h =
[
    [ "EncoderVAAPIPrivate", "struct_a_v_qt_1_1_encoder_v_a_a_p_i_private.html", "struct_a_v_qt_1_1_encoder_v_a_a_p_i_private" ],
    [ "Frame", "struct_a_v_qt_1_1_encoder_v_a_a_p_i_private_1_1_frame.html", "struct_a_v_qt_1_1_encoder_v_a_a_p_i_private_1_1_frame" ],
    [ "TRANSCODE_ENCODERVAAPIPRIVATE_H", "_encoder_v_a_a_p_i__p_8h.html#a381341940bc78b7b83f66a36a51fd6ca", null ]
];