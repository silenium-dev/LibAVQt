var _encoder_v_a_a_p_i_8cpp =
[
    [ "NOW", "_encoder_v_a_a_p_i_8cpp.html#a9e1f10144cee8f7e6efb6408fb0f8f34", null ],
    [ "TIME_S", "_encoder_v_a_a_p_i_8cpp.html#a1f5903e977abdcbbd199238fb848c64f", null ],
    [ "TIME_US", "_encoder_v_a_a_p_i_8cpp.html#ab3f545ed4b1dfe82e4b494e41c1a477d", null ]
];