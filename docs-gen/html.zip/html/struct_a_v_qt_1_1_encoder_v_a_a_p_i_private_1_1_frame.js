var struct_a_v_qt_1_1_encoder_v_a_a_p_i_private_1_1_frame =
[
    [ "frame", "struct_a_v_qt_1_1_encoder_v_a_a_p_i_private_1_1_frame.html#ab476b66f09349f8bdff8847c776dd9dd", null ],
    [ "framerate", "struct_a_v_qt_1_1_encoder_v_a_a_p_i_private_1_1_frame.html#adc6a48691f2c843996ee39827a9d5a8b", null ],
    [ "timeBase", "struct_a_v_qt_1_1_encoder_v_a_a_p_i_private_1_1_frame.html#a53b4dc99641d31887430c77a5f3ce3c2", null ]
];